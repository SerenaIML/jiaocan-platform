/*
 * 教参教案 · 试阅平台 — App Logic
 * Design System: Modern Minimal + Soft Warm
 * Hierarchy: Publisher > Stage > Subject > Version > Grade > Book
 */

'use strict';

// ========================================
// Navigation: Open a book in trial.html
// ========================================
function openBook(bookUrl, bookTitle) {
  if (!bookUrl) {
    showNotification('该书暂无试阅链接');
    return;
  }
  var encodedUrl = encodeURIComponent(bookUrl);
  var encodedTitle = encodeURIComponent(bookTitle);
  window.location.href = 'trial.html?url=' + encodedUrl + '&title=' + encodedTitle;
}

// ========================================
// Notification Toast
// ========================================
function showNotification(msg) {
  var el = document.getElementById('notification');
  if (!el) {
    el = document.createElement('div');
    el.id = 'notification';
    document.body.appendChild(el);
  }
  el.textContent = msg;
  // Trigger animation
  requestAnimationFrame(function() {
    el.style.opacity = '1';
    el.style.transform = 'translateX(-50%) translateY(0)';
  });
  // Auto dismiss
  setTimeout(function() {
    el.style.opacity = '0';
    el.style.transform = 'translateX(-50%) translateY(20px)';
  }, 3000);
}

// ========================================
// Count helpers
// ========================================

/** Count total books in a stage */
function countStageBooks(stage) {
  var sum = 0;
  for (var i = 0; i < stage.subjects.length; i++) {
    sum += stage.subjects[i].count;
  }
  return sum;
}

/** Count total books in a grade group */
function countGradeBooks(books) {
  return books ? books.length : 0;
}

// ========================================
// Render helpers
// ========================================

/**
 * Render a single book card (Level 6)
 */
function renderBookCard(book) {
  var termLabel = book.term
    ? '<span class="term-tag">' + escapeHtml(book.term) + '</span>'
    : '';
  // Shorten title by removing year/edition prefix
  var shortTitle = book.title.replace(/^\d{4}年[春秋]+版\s*/, '');
  return (
    '<div class="book-card" data-url="' + escapeAttr(book.url) + '" data-title="' + escapeAttr(book.title) + '">' +
      '<div class="book-info-line">' +
        termLabel +
        '<span class="book-title-text">' + escapeHtml(shortTitle) + '</span>' +
        '<span class="book-pages">' + (book.pages || '—') + '页</span>' +
      '</div>' +
      '<button class="trial-btn" data-url="' + escapeAttr(book.url) + '" data-title="' + escapeAttr(book.title) + '">试阅</button>' +
    '</div>'
  );
}

/**
 * Render the grade grid under a version (Level 5)
 */
function renderGrades(pubId, stageName, subjName, version) {
  var gradeEntries = Object.entries(version.grades);
  if (gradeEntries.length === 0) {
    return '<div class="no-books">该版本暂无数据</div>';
  }

  var html = '<div class="grade-grid">';
  for (var i = 0; i < gradeEntries.length; i++) {
    var grade = gradeEntries[i][0];
    var books = gradeEntries[i][1];
    html += (
      '<div class="grade-tile" data-grade="' + escapeAttr(grade) + '">' +
        '<div class="grade-tile-head">' +
          '<span class="grade-name">' + escapeHtml(grade) + '</span>' +
          '<span class="grade-count">' + books.length + ' 本</span>' +
          '<span class="expand-icon">▸</span>' +
        '</div>' +
        '<div class="grade-tile-body" style="display:none;">'
    );
    for (var j = 0; j < books.length; j++) {
      html += renderBookCard(books[j]);
    }
    html += '</div></div>';
  }
  html += '</div>';
  return html;
}

/**
 * Render version tabs + content (Level 4)
 */
function renderVersions(pubId, stageName, subj) {
  // Single version: show label only
  if (subj.versions.length === 1) {
    var v = subj.versions[0];
    return (
      '<div class="version-label-only">' +
        '<span class="version-label-tag">' + escapeHtml(v.version) + '</span>' +
        '<span class="version-label-count">（' + v.count + ' 本）</span>' +
      '</div>' +
      '<div class="version-contents">' +
        '<div class="version-content active">' + renderGrades(pubId, stageName, subj.name, v) + '</div>' +
      '</div>'
    );
  }

  // Multiple versions: render tabs
  var tabsHtml = '<div class="version-tabs">';
  var contentsHtml = '';
  for (var i = 0; i < subj.versions.length; i++) {
    var v = subj.versions[i];
    var active = i === 0 ? 'active' : '';
    tabsHtml += (
      '<div class="version-tab ' + active + '" data-version="' + escapeAttr(v.version) + '">' +
        escapeHtml(v.version) + '（' + v.count + '）' +
      '</div>'
    );
    contentsHtml += (
      '<div class="version-content ' + active + '" data-version="' + escapeAttr(v.version) + '">' +
        renderGrades(pubId, stageName, subj.name, v) +
      '</div>'
    );
  }
  tabsHtml += '</div>';
  return tabsHtml + '<div class="version-contents">' + contentsHtml + '</div>';
}

/**
 * Render subject rows for a stage (Level 3)
 */
function renderSubjects(pubId, stage) {
  var html = '<div class="subject-list">';
  for (var i = 0; i < stage.subjects.length; i++) {
    var subj = stage.subjects[i];
    html += (
      '<div class="subject-row" data-pub="' + escapeAttr(pubId) + '" data-stage="' + escapeAttr(stage.stage) + '" data-subj="' + escapeAttr(subj.name) + '">' +
        '<div class="subject-row-head">' +
          '<span class="subject-name">' + escapeHtml(subj.name) + '</span>' +
          '<span class="subject-count">' + subj.count + ' 本</span>' +
          '<span class="expand-icon">▾</span>' +
        '</div>' +
        '<div class="subject-row-body" style="display:none;">' +
          renderVersions(pubId, stage.stage, subj) +
        '</div>' +
      '</div>'
    );
  }
  html += '</div>';
  return html;
}

/**
 * Render stage tabs + content for a publisher (Level 2)
 */
function renderStages(pub) {
  var tabsHtml = '<div class="stage-tabs">';
  var contentsHtml = '';

  for (var i = 0; i < pub.categories.length; i++) {
    var stage = pub.categories[i];
    var isActive = i === 0 ? 'active' : '';
    tabsHtml += (
      '<div class="stage-tab ' + isActive + '" data-pub="' + escapeAttr(pub.id) + '" data-stage="' + escapeAttr(stage.stage) + '">' +
        escapeHtml(stage.stage) + '（' + countStageBooks(stage) + '）' +
      '</div>'
    );
    contentsHtml += (
      '<div class="stage-content ' + isActive + '" data-stage="' + escapeAttr(stage.stage) + '">' +
        renderSubjects(pub.id, stage) +
      '</div>'
    );
  }
  tabsHtml += '</div>';

  return tabsHtml + contentsHtml;
}

// ========================================
// Main Render: Publisher Cards (Level 1)
// ========================================
function renderPublishers() {
  var container = document.getElementById('publisherContainer');
  if (!container) return;

  if (!window.publishers || window.publishers.length === 0) {
    container.innerHTML =
      '<div class="empty-state">' +
        '<div class="icon">📚</div>' +
        '<p>暂无比添加的教参资源</p>' +
      '</div>';
    return;
  }

  var html = '';
  for (var i = 0; i < window.publishers.length; i++) {
    var pub = window.publishers[i];
    html += (
      '<section class="publisher-card" data-id="' + escapeAttr(pub.id) + '">' +
        // Publisher Header
        '<div class="publisher-header">' +
          '<div class="publisher-logo">' + (pub.logo || '📘') + '</div>' +
          '<div class="publisher-meta">' +
            '<div class="publisher-name">' + escapeHtml(pub.name) + '</div>' +
            '<div class="publisher-series">' + escapeHtml(pub.series) + '</div>' +
            '<div class="publisher-desc">' + escapeHtml(pub.description) + '</div>' +
            '<div class="publisher-stats">' +
              '<span class="stat">📚 共 <strong>' + (pub.totalBooks || '—') + '</strong> 本教参</span>' +
              '<span class="stat">🏫 覆盖 <strong>' + (pub.categories ? pub.categories.length : 0) + '</strong> 个学段</span>' +
            '</div>' +
          '</div>' +
        '</div>' +
        // Category section with stage tabs
        '<div class="category-section">' +
          renderStages(pub) +
        '</div>' +
      '</section>'
    );
  }

  container.innerHTML = html;
}

// ========================================
// Event Delegation (Single listener)
// ========================================
document.addEventListener('click', function(e) {
  var target = e.target;

  // --- Stage Tab switch (Level 2) ---
  var stageTab = target.closest('.stage-tab');
  if (stageTab) {
    var pubCard = stageTab.closest('.publisher-card');
    var stageName = stageTab.dataset.stage;
    // Deactivate all tabs in this group
    var siblings = stageTab.parentElement.querySelectorAll('.stage-tab');
    for (var i = 0; i < siblings.length; i++) {
      siblings[i].classList.remove('active');
    }
    stageTab.classList.add('active');
    // Show corresponding content
    var contents = pubCard.querySelectorAll('.stage-content');
    for (var j = 0; j < contents.length; j++) {
      contents[j].classList.toggle('active', contents[j].dataset.stage === stageName);
    }
    return;
  }

  // --- Subject Row toggle (Level 3) ---
  var subjectHead = target.closest('.subject-row-head');
  if (subjectHead) {
    var row = subjectHead.parentElement;
    var body = row.querySelector('.subject-row-body');
    var isOpen = body.style.display !== 'none';
    body.style.display = isOpen ? 'none' : 'block';
    row.classList.toggle('open', !isOpen);
    return;
  }

  // --- Grade Tile toggle (Level 5) ---
  var gradeHead = target.closest('.grade-tile-head');
  if (gradeHead) {
    var tile = gradeHead.parentElement;
    var body = tile.querySelector('.grade-tile-body');
    var isOpen = body.style.display !== 'none';
    body.style.display = isOpen ? 'none' : 'block';
    tile.classList.toggle('open', !isOpen);
    return;
  }

  // --- Version Tab switch (Level 4) ---
  var versionTab = target.closest('.version-tab');
  if (versionTab) {
    var version = versionTab.dataset.version;
    var subjectBody = versionTab.closest('.subject-row-body');
    // Deactivate all version tabs
    var tabs = subjectBody.querySelectorAll('.version-tab');
    for (var k = 0; k < tabs.length; k++) {
      tabs[k].classList.remove('active');
    }
    versionTab.classList.add('active');
    // Show corresponding content
    var versionContents = subjectBody.querySelectorAll('.version-content');
    for (var m = 0; m < versionContents.length; m++) {
      versionContents[m].classList.toggle('active', versionContents[m].dataset.version === version);
    }
    return;
  }

  // --- Trial Button (direct click) ---
  var trialBtn = target.closest('.trial-btn');
  if (trialBtn) {
    e.stopPropagation();
    var url = trialBtn.dataset.url;
    var title = trialBtn.dataset.title;
    if (url) {
      openBook(url, title);
    } else {
      showNotification('该书暂无试阅链接');
    }
    return;
  }

  // --- Book Card click (anywhere on card) ---
  var bookCard = target.closest('.book-card');
  if (bookCard) {
    var url = bookCard.dataset.url;
    var title = bookCard.dataset.title;
    if (url) {
      openBook(url, title);
    }
    return;
  }
});

// ========================================
// Utility: Escape HTML to prevent injection
// ========================================
function escapeHtml(str) {
  if (!str) return '';
  var div = document.createElement('div');
  div.appendChild(document.createTextNode(str));
  return div.innerHTML;
}

function escapeAttr(str) {
  if (!str) return '';
  return String(str).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ========================================
// Initialize
// ========================================
document.addEventListener('DOMContentLoaded', function() {
  renderPublishers();
});
