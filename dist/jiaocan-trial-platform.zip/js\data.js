const siteInfo = {
  title: '教参教案 · 试阅平台',
  description: '汇集多家出版社的教学参考书与教案资源，按学段、学科、版本分类展示，一键试阅'
};

const publishers = [
  {
  "id": "qhxk-edu",
  "name": "上海清华新课标教育图书",
  "series": "教学设计与指导",
  "logo": "📘",
  "description": "华东师范大学出版社出版 · 《教学设计与指导》系列样书",
  "trialType": "iframe",
  "trialUrl": "https://book.yunzhan365.com/bookcase/vjud/index.html",
  "totalBooks": 187,
  "categories": [
    {
      "stage": "小学",
      "subjects": [
        {
          "name": "语文",
          "count": 13,
          "versions": [
            {
              "version": "统编版",
              "count": 13,
              "grades": {
                "一年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编版小学语文 教学设计与指导 一年级上册",
                    "url": "https://book.yunzhan365.com/luloc/vool/",
                    "pages": 32,
                    "bLink": "vool"
                  },
                  {
                    "term": "下册",
                    "title": "统编小学语文 教学设计与指导 一年级下册",
                    "url": "https://book.yunzhan365.com/luloc/ufzf/",
                    "pages": 31,
                    "bLink": "ufzf"
                  }
                ],
                "二年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编版小学语文 教学设计与指导 二年级上册",
                    "url": "https://book.yunzhan365.com/luloc/tfoz/",
                    "pages": 32,
                    "bLink": "tfoz"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 统编版小学语文 教学设计与指导 二年级下册",
                    "url": "https://book.yunzhan365.com/luloc/cfur/",
                    "pages": 46,
                    "bLink": "cfur"
                  }
                ],
                "三年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编版小学语文 教学设计与指导 三年级上册",
                    "url": "https://book.yunzhan365.com/luloc/raam/",
                    "pages": 32,
                    "bLink": "raam"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 统编版小学语文 教学设计与指导 三年级下册",
                    "url": "https://book.yunzhan365.com/luloc/vpns/",
                    "pages": 51,
                    "bLink": "vpns"
                  }
                ],
                "四年级": [
                  {
                    "term": "上册",
                    "title": " 2025年秋版 统编小学语文 教学设计与指导 四年级上册",
                    "url": "https://book.yunzhan365.com/luloc/bdbc/",
                    "pages": 32,
                    "bLink": "bdbc"
                  },
                  {
                    "term": "下册",
                    "title": " 统编小学语文 教学设计与指导 四年级下册",
                    "url": "https://book.yunzhan365.com/luloc/smyh/",
                    "pages": 15,
                    "bLink": "smyh"
                  }
                ],
                "五年级": [
                  {
                    "term": "上册",
                    "title": " 2025年秋版 统编小学语文 教学设计与指导 五年级上册",
                    "url": "https://book.yunzhan365.com/luloc/yuxh/",
                    "pages": 32,
                    "bLink": "yuxh"
                  },
                  {
                    "term": "下册",
                    "title": " 统编小学语文 教学设计与指导 五年级下册",
                    "url": "https://book.yunzhan365.com/luloc/nhlh/",
                    "pages": 16,
                    "bLink": "nhlh"
                  }
                ],
                "六年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编小学语文 教学设计与指导 六年级上册",
                    "url": "https://book.yunzhan365.com/luloc/dsli/",
                    "pages": 32,
                    "bLink": "dsli"
                  },
                  {
                    "term": "上册",
                    "title": "统编小学语文 教学设计与指导 六年级上册（五四学制）",
                    "url": "https://book.yunzhan365.com/luloc/hoai/",
                    "pages": 32,
                    "bLink": "hoai"
                  },
                  {
                    "term": "下册",
                    "title": "统编小学语文 教学设计与指导 六年级下册",
                    "url": "https://book.yunzhan365.com/luloc/vurd/",
                    "pages": 16,
                    "bLink": "vurd"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "数学",
          "count": 26,
          "versions": [
            {
              "version": "人教版",
              "count": 12,
              "grades": {
                "一年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版小学数学教科书教学设计与指导 一年级上册",
                    "url": "https://book.yunzhan365.com/luloc/xswa/",
                    "pages": 32,
                    "bLink": "xswa"
                  },
                  {
                    "term": "下册",
                    "title": " 人教版小学数学教科书教学设计与指导 一年级下册",
                    "url": "https://book.yunzhan365.com/luloc/uujd/",
                    "pages": 31,
                    "bLink": "uujd"
                  }
                ],
                "二年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版小学数学教科书教学设计与指导 二年级上册",
                    "url": "https://book.yunzhan365.com/luloc/unhj/",
                    "pages": 32,
                    "bLink": "unhj"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 人教版小学数学教科书教学设计与指导 二年级下册",
                    "url": "https://book.yunzhan365.com/luloc/rmre/",
                    "pages": 39,
                    "bLink": "rmre"
                  }
                ],
                "三年级": [
                  {
                    "term": "上册",
                    "title": " 2025年秋版 人教版小学数学教科书教学设计与指导 三年级上册",
                    "url": "https://book.yunzhan365.com/luloc/nwjb/",
                    "pages": 32,
                    "bLink": "nwjb"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 人教版小学数学教科书教学设计与指导 三年级下册",
                    "url": "https://book.yunzhan365.com/luloc/jtpx/",
                    "pages": 33,
                    "bLink": "jtpx"
                  }
                ],
                "四年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版小学数学教科书教学设计与指导 四年级上册",
                    "url": "https://book.yunzhan365.com/luloc/bygq/",
                    "pages": 32,
                    "bLink": "bygq"
                  },
                  {
                    "term": "下册",
                    "title": "人教版小学数学教科书教学设计与指导 四年级下册",
                    "url": "https://book.yunzhan365.com/luloc/rlqu/",
                    "pages": 16,
                    "bLink": "rlqu"
                  }
                ],
                "五年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版小学数学教科书教学设计与指导 五年级上册",
                    "url": "https://book.yunzhan365.com/luloc/tfmt/",
                    "pages": 32,
                    "bLink": "tfmt"
                  },
                  {
                    "term": "下册",
                    "title": "人教版小学数学教科书教学设计与指导 五年级下册",
                    "url": "https://book.yunzhan365.com/luloc/thjp/",
                    "pages": 16,
                    "bLink": "thjp"
                  }
                ],
                "六年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版小学数学教科书教学设计与指导 六年级上册",
                    "url": "https://book.yunzhan365.com/luloc/zsbc/",
                    "pages": 32,
                    "bLink": "zsbc"
                  },
                  {
                    "term": "下册",
                    "title": "人教版小学数学教科书教学设计与指导 六年级下册",
                    "url": "https://book.yunzhan365.com/luloc/obih/",
                    "pages": 16,
                    "bLink": "obih"
                  }
                ]
              }
            },
            {
              "version": "冀教版",
              "count": 2,
              "grades": {
                "一年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 冀教版小学数学教科书教学设计与指导 一年级上册",
                    "url": "https://book.yunzhan365.com/luloc/glnz/",
                    "pages": 32,
                    "bLink": "glnz"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 冀教版小学数学教科书教学设计与指导 一年级下册",
                    "url": "https://book.yunzhan365.com/luloc/detg/",
                    "pages": 33,
                    "bLink": "detg"
                  }
                ]
              }
            },
            {
              "version": "北师大版",
              "count": 6,
              "grades": {
                "一年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 北师版小学数学教科书教学设计与指导 一年级上册",
                    "url": "https://book.yunzhan365.com/luloc/oeum/",
                    "pages": 32,
                    "bLink": "oeum"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 北师版小学数学教科书教学设计与指导 一年级下册",
                    "url": "https://book.yunzhan365.com/luloc/jyia/",
                    "pages": 43,
                    "bLink": "jyia"
                  }
                ],
                "三年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 北师版小学数学教科书教学设计与指导 三年级上册",
                    "url": "https://book.yunzhan365.com/luloc/czcr/",
                    "pages": 32,
                    "bLink": "czcr"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 北师版小学数学教科书教学设计与指导 三年级下册",
                    "url": "https://book.yunzhan365.com/luloc/bvjw/",
                    "pages": 41,
                    "bLink": "bvjw"
                  }
                ],
                "二年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 北师版小学数学教科书教学设计与指导 二年级上册",
                    "url": "https://book.yunzhan365.com/luloc/raei/",
                    "pages": 32,
                    "bLink": "raei"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 北师版小学数学教科书教学设计与指导 二年级下册",
                    "url": "https://book.yunzhan365.com/luloc/bsba/",
                    "pages": 38,
                    "bLink": "bsba"
                  }
                ]
              }
            },
            {
              "version": "苏教版",
              "count": 6,
              "grades": {
                "一年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 苏教版小学数学教科书教学设计与指导 一年级上册",
                    "url": "https://book.yunzhan365.com/luloc/lriz/",
                    "pages": 32,
                    "bLink": "lriz"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 苏教版小学数学教科书教学设计与指导 一年级下册",
                    "url": "https://book.yunzhan365.com/luloc/ltfi/",
                    "pages": 32,
                    "bLink": "ltfi"
                  }
                ],
                "二年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 苏教版小学数学教科书教学设计与指导 二年级上册",
                    "url": "https://book.yunzhan365.com/luloc/wqnx/",
                    "pages": 32,
                    "bLink": "wqnx"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 苏教版小学数学教科书教学设计与指导 二年级下册",
                    "url": "https://book.yunzhan365.com/luloc/hwkb/",
                    "pages": 43,
                    "bLink": "hwkb"
                  }
                ],
                "三年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 苏教版小学数学教科书教学设计与指导 三年级上册",
                    "url": "https://book.yunzhan365.com/luloc/pcld/",
                    "pages": 32,
                    "bLink": "pcld"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 苏教版小学数学教科书教学设计与指导 三年级下册",
                    "url": "https://book.yunzhan365.com/luloc/phlj/",
                    "pages": 41,
                    "bLink": "phlj"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "英语",
          "count": 12,
          "versions": [
            {
              "version": "人教版",
              "count": 4,
              "grades": {
                "三年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版小学英语教科书教学设计与指导 三年级上册",
                    "url": "https://book.yunzhan365.com/luloc/rjnc/",
                    "pages": 32,
                    "bLink": "rjnc"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 人教版小学英语教科书教学设计与指导 三年级下册",
                    "url": "https://book.yunzhan365.com/luloc/ihif/",
                    "pages": 42,
                    "bLink": "ihif"
                  }
                ],
                "四年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版小学英语教科书教学设计与指导 四年级上册",
                    "url": "https://book.yunzhan365.com/luloc/swjf/",
                    "pages": 32,
                    "bLink": "swjf"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 人教版小学英语教科书教学设计与指导 四年级下册",
                    "url": "https://book.yunzhan365.com/luloc/tbkq/",
                    "pages": 32,
                    "bLink": "tbkq"
                  }
                ]
              }
            },
            {
              "version": "外研版",
              "count": 4,
              "grades": {
                "三年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 外研版小学英语教科书教学设计与指导 三年级上册",
                    "url": "https://book.yunzhan365.com/luloc/jryc/",
                    "pages": 32,
                    "bLink": "jryc"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 外研版小学英语教科书教学设计与指导 三年级下册",
                    "url": "https://book.yunzhan365.com/luloc/rsdp/",
                    "pages": 53,
                    "bLink": "rsdp"
                  }
                ],
                "四年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 外研版小学英语教科书教学设计与指导 四年级上册",
                    "url": "https://book.yunzhan365.com/luloc/dqzx/",
                    "pages": 32,
                    "bLink": "dqzx"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 外研版小学英语教科书教学设计与指导 四年级下册",
                    "url": "https://book.yunzhan365.com/luloc/pbhq/",
                    "pages": 48,
                    "bLink": "pbhq"
                  }
                ]
              }
            },
            {
              "version": "译林版",
              "count": 4,
              "grades": {
                "三年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 译林版小学英语教科书教学设计与指导 三年级上册",
                    "url": "https://book.yunzhan365.com/luloc/ockc/",
                    "pages": 32,
                    "bLink": "ockc"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 译林版小学英语教科书教学设计与指导 三年级下册",
                    "url": "https://book.yunzhan365.com/luloc/lgag/",
                    "pages": 39,
                    "bLink": "lgag"
                  }
                ],
                "四年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 译林版小学英语教科书教学设计与指导 四年级上册",
                    "url": "https://book.yunzhan365.com/luloc/tjcq/",
                    "pages": 32,
                    "bLink": "tjcq"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 译林版小学英语教科书教学设计与指导 四年级下册",
                    "url": "https://book.yunzhan365.com/luloc/zoln/",
                    "pages": 34,
                    "bLink": "zoln"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "道德与法治",
          "count": 12,
          "versions": [
            {
              "version": "统编版",
              "count": 12,
              "grades": {
                "一年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编小学道德与法治 教学设计与指导 一年级上册",
                    "url": "https://book.yunzhan365.com/luloc/gljf/",
                    "pages": 32,
                    "bLink": "gljf"
                  },
                  {
                    "term": "下册",
                    "title": "统编小学道德与法治 教学设计与指导 一年级下册",
                    "url": "https://book.yunzhan365.com/luloc/wkev/",
                    "pages": 52,
                    "bLink": "wkev"
                  }
                ],
                "二年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编小学道德与法治 教学设计与指导 二年级上册",
                    "url": "https://book.yunzhan365.com/luloc/cjom/",
                    "pages": 32,
                    "bLink": "cjom"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 统编小学道德与法治 教学设计与指导 二年级下册",
                    "url": "https://book.yunzhan365.com/luloc/efpt/",
                    "pages": 50,
                    "bLink": "efpt"
                  }
                ],
                "三年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编小学道德与法治 教学设计与指导 三年级上册",
                    "url": "https://book.yunzhan365.com/luloc/qeco/",
                    "pages": 32,
                    "bLink": "qeco"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 统编小学道德与法治 教学设计与指导 三年级下册",
                    "url": "https://book.yunzhan365.com/luloc/rhto/",
                    "pages": 51,
                    "bLink": "rhto"
                  }
                ],
                "四年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编小学道德与法治 教学设计与指导 四年级上册",
                    "url": "https://book.yunzhan365.com/luloc/anen/",
                    "pages": 32,
                    "bLink": "anen"
                  },
                  {
                    "term": "下册",
                    "title": "统编小学道德与法治 教学设计与指导 四年级下册",
                    "url": "https://book.yunzhan365.com/luloc/gdda/",
                    "pages": 15,
                    "bLink": "gdda"
                  }
                ],
                "五年级": [
                  {
                    "term": "上册",
                    "title": " 2025年秋版 统编小学道德与法治 教学设计与指导 五年级上册",
                    "url": "https://book.yunzhan365.com/luloc/mqdd/",
                    "pages": 32,
                    "bLink": "mqdd"
                  },
                  {
                    "term": "下册",
                    "title": " 统编小学道德与法治 教学设计与指导 五年级下册",
                    "url": "https://book.yunzhan365.com/luloc/neas/",
                    "pages": 8,
                    "bLink": "neas"
                  }
                ],
                "六年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编小学道德与法治 教学设计与指导 六年级上册",
                    "url": "https://book.yunzhan365.com/luloc/zmmt/",
                    "pages": 32,
                    "bLink": "zmmt"
                  },
                  {
                    "term": "下册",
                    "title": " 统编小学道德与法治 教学设计与指导 六年级下册",
                    "url": "https://book.yunzhan365.com/luloc/gtsi/",
                    "pages": 15,
                    "bLink": "gtsi"
                  }
                ]
              }
            }
          ]
        }
      ]
    },
    {
      "stage": "初中",
      "subjects": [
        {
          "name": "语文",
          "count": 6,
          "versions": [
            {
              "version": "统编版",
              "count": 6,
              "grades": {
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编初中语文 教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/uinv/",
                    "pages": 32,
                    "bLink": "uinv"
                  },
                  {
                    "term": "下册",
                    "title": "统编初中语文 教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/knhd/",
                    "pages": 38,
                    "bLink": "knhd"
                  }
                ],
                "八年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编初中语文 教学设计与指导 八年级上册",
                    "url": "https://book.yunzhan365.com/luloc/lsmn/",
                    "pages": 32,
                    "bLink": "lsmn"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 统编初中语文 教学设计与指导 八年级下册",
                    "url": "https://book.yunzhan365.com/luloc/dgaf/",
                    "pages": 51,
                    "bLink": "dgaf"
                  }
                ],
                "九年级": [
                  {
                    "term": "上册",
                    "title": " 2025年秋版 统编初中语文 教学设计与指导 九年级上册",
                    "url": "https://book.yunzhan365.com/luloc/sdov/",
                    "pages": 32,
                    "bLink": "sdov"
                  },
                  {
                    "term": "下册",
                    "title": " 统编初中语文 教学设计与指导 九年级下册",
                    "url": "https://book.yunzhan365.com/luloc/fsgc/",
                    "pages": 13,
                    "bLink": "fsgc"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "数学",
          "count": 22,
          "versions": [
            {
              "version": "人教版",
              "count": 4,
              "grades": {
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版初中数学 教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/uwen/",
                    "pages": 32,
                    "bLink": "uwen"
                  },
                  {
                    "term": "下册",
                    "title": "人教版初中数学 教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/dnjc/",
                    "pages": 30,
                    "bLink": "dnjc"
                  }
                ],
                "八年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版初中数学 教学设计与指导 八年级上册",
                    "url": "https://book.yunzhan365.com/luloc/zlll/",
                    "pages": 32,
                    "bLink": "zlll"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 人教版初中数学 教学设计与指导 八年级下册",
                    "url": "https://book.yunzhan365.com/luloc/pbll/",
                    "pages": 15,
                    "bLink": "pbll"
                  }
                ]
              }
            },
            {
              "version": "北师大版",
              "count": 2,
              "grades": {
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 北师版初中数学 教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/arfu/",
                    "pages": 32,
                    "bLink": "arfu"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 北师版初中数学 教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/alxv/",
                    "pages": 51,
                    "bLink": "alxv"
                  }
                ]
              }
            },
            {
              "version": "华师版",
              "count": 4,
              "grades": {
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 华师版初中数学 教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/jaoq/",
                    "pages": 32,
                    "bLink": "jaoq"
                  },
                  {
                    "term": "下册",
                    "title": "华师版初中数学 教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/nxfy/",
                    "pages": 56,
                    "bLink": "nxfy"
                  }
                ],
                "八年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 华师版初中数学 教学设计与指导 八年级上册",
                    "url": "https://book.yunzhan365.com/luloc/yodo/",
                    "pages": 32,
                    "bLink": "yodo"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 华师版初中数学 教学设计与指导 八年级下册",
                    "url": "https://book.yunzhan365.com/luloc/tdzn/",
                    "pages": 37,
                    "bLink": "tdzn"
                  }
                ]
              }
            },
            {
              "version": "核心素养系列",
              "count": 8,
              "grades": {
                "核心素养研究": [
                  {
                    "term": "",
                    "title": "初中数学核心素养行为表现及教学案例研究·运算能力",
                    "url": "https://book.yunzhan365.com/luloc/ghgh/",
                    "pages": 42,
                    "bLink": "ghgh"
                  },
                  {
                    "term": "",
                    "title": "初中数学核心素养行为表现及教学案例研究·应用意识与创新意识",
                    "url": "https://book.yunzhan365.com/luloc/ggar/",
                    "pages": 45,
                    "bLink": "ggar"
                  },
                  {
                    "term": "",
                    "title": "初中数学核心素养行为表现及教学案例研究·推理能力",
                    "url": "https://book.yunzhan365.com/luloc/eabg/",
                    "pages": 42,
                    "bLink": "eabg"
                  },
                  {
                    "term": "",
                    "title": "初中数学核心素养行为表现及教学案例研究·数据观念",
                    "url": "https://book.yunzhan365.com/luloc/czvb/",
                    "pages": 50,
                    "bLink": "czvb"
                  },
                  {
                    "term": "",
                    "title": "初中数学核心素养行为表现及教学案例研究·模型观念",
                    "url": "https://book.yunzhan365.com/luloc/clzf/",
                    "pages": 49,
                    "bLink": "clzf"
                  },
                  {
                    "term": "",
                    "title": "初中数学核心素养行为表现及教学案例研究·空间观念",
                    "url": "https://book.yunzhan365.com/luloc/saoe/",
                    "pages": 48,
                    "bLink": "saoe"
                  },
                  {
                    "term": "",
                    "title": "初中数学核心素养行为表现及教学案例研究·几何直观",
                    "url": "https://book.yunzhan365.com/luloc/rdvj/",
                    "pages": 47,
                    "bLink": "rdvj"
                  },
                  {
                    "term": "",
                    "title": "初中数学核心素养行为表现及教学案例研究·抽象能力",
                    "url": "https://book.yunzhan365.com/luloc/ynlt/",
                    "pages": 46,
                    "bLink": "ynlt"
                  }
                ]
              }
            },
            {
              "version": "浙教版",
              "count": 2,
              "grades": {
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 浙教版初中数学 教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/pjqq/",
                    "pages": 32,
                    "bLink": "pjqq"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 浙教版初中数学 教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/bvbs/",
                    "pages": 48,
                    "bLink": "bvbs"
                  }
                ]
              }
            },
            {
              "version": "苏科版",
              "count": 2,
              "grades": {
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 苏科版初中数学 教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/hxek/",
                    "pages": 32,
                    "bLink": "hxek"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 苏科版初中数学 教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/novy/",
                    "pages": 39,
                    "bLink": "novy"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "英语",
          "count": 10,
          "versions": [
            {
              "version": "人教版",
              "count": 4,
              "grades": {
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版初中英语教科书教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/cjzt/",
                    "pages": 32,
                    "bLink": "cjzt"
                  },
                  {
                    "term": "下册",
                    "title": "人教版初中英语教科书教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/zofn/",
                    "pages": 29,
                    "bLink": "zofn"
                  }
                ],
                "八年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版初中英语教科书教学设计与指导 八年级上册",
                    "url": "https://book.yunzhan365.com/luloc/dqyq/",
                    "pages": 32,
                    "bLink": "dqyq"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 人教版初中英语教科书教学设计与指导 八年级下册",
                    "url": "https://book.yunzhan365.com/luloc/zqyf/",
                    "pages": 44,
                    "bLink": "zqyf"
                  }
                ]
              }
            },
            {
              "version": "外研版",
              "count": 2,
              "grades": {
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 外研版初中英语教科书教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/yefs/",
                    "pages": 32,
                    "bLink": "yefs"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 外研版初中英语教科书教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/vrvy/",
                    "pages": 51,
                    "bLink": "vrvy"
                  }
                ]
              }
            },
            {
              "version": "译林版",
              "count": 4,
              "grades": {
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 译林版初中英语教科书教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/obva/",
                    "pages": 32,
                    "bLink": "obva"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 译林版初中英语教科书教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/lfph/",
                    "pages": 48,
                    "bLink": "lfph"
                  }
                ],
                "八年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 译林版初中英语教科书教学设计与指导 八年级上册",
                    "url": "https://book.yunzhan365.com/luloc/hkeu/",
                    "pages": 32,
                    "bLink": "hkeu"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 译林版初中英语教科书教学设计与指导 八年级下册",
                    "url": "https://book.yunzhan365.com/luloc/tgof/",
                    "pages": 33,
                    "bLink": "tgof"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "道德与法治",
          "count": 6,
          "versions": [
            {
              "version": "统编版",
              "count": 6,
              "grades": {
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编初中道德与法治 教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/cbpe/",
                    "pages": 32,
                    "bLink": "cbpe"
                  },
                  {
                    "term": "下册",
                    "title": "统编初中道德与法治 教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/zxbi/",
                    "pages": 48,
                    "bLink": "zxbi"
                  }
                ],
                "八年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编初中道德与法治 教学设计与指导 八年级上册",
                    "url": "https://book.yunzhan365.com/luloc/mixi/",
                    "pages": 32,
                    "bLink": "mixi"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 统编初中道德与法治 教学设计与指导 八年级下册",
                    "url": "https://book.yunzhan365.com/luloc/nqmr/",
                    "pages": 51,
                    "bLink": "nqmr"
                  }
                ],
                "九年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编初中道德与法治 教学设计与指导 九年级上册",
                    "url": "https://book.yunzhan365.com/luloc/cvcz/",
                    "pages": 32,
                    "bLink": "cvcz"
                  },
                  {
                    "term": "下册",
                    "title": " 统编初中道德与法治 教学设计与指导 九年级下册",
                    "url": "https://book.yunzhan365.com/luloc/hchf/",
                    "pages": 16,
                    "bLink": "hchf"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "历史",
          "count": 6,
          "versions": [
            {
              "version": "统编版",
              "count": 6,
              "grades": {
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编版初中历史 教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/wppo/",
                    "pages": 32,
                    "bLink": "wppo"
                  },
                  {
                    "term": "下册",
                    "title": "统编版初中历史 教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/sebu/",
                    "pages": 48,
                    "bLink": "sebu"
                  }
                ],
                "八年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 统编版初中历史 教学设计与指导 八年级上册",
                    "url": "https://book.yunzhan365.com/luloc/gvjj/",
                    "pages": 32,
                    "bLink": "gvjj"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 统编版初中历史 教学设计与指导 八年级下册",
                    "url": "https://book.yunzhan365.com/luloc/qblv/",
                    "pages": 36,
                    "bLink": "qblv"
                  }
                ],
                "九年级": [
                  {
                    "term": "上册",
                    "title": " 2025年秋版 统编初中历史 教学设计与指导 九年级上册",
                    "url": "https://book.yunzhan365.com/luloc/ypii/",
                    "pages": 32,
                    "bLink": "ypii"
                  },
                  {
                    "term": "下册",
                    "title": "统编初中历史 教学设计与指导 九年级下册",
                    "url": "https://book.yunzhan365.com/luloc/kpqg/",
                    "pages": 16,
                    "bLink": "kpqg"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "地理",
          "count": 6,
          "versions": [
            {
              "version": "人教版",
              "count": 3,
              "grades": {
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版初中地理 教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/iidp/",
                    "pages": 32,
                    "bLink": "iidp"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 人教版初中地理 教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/itvq/",
                    "pages": 20,
                    "bLink": "itvq"
                  }
                ],
                "八年级": [
                  {
                    "term": "下册",
                    "title": "2026年春版 人教版初中地理 教学设计与指导 八年级下册",
                    "url": "https://book.yunzhan365.com/luloc/ujei/",
                    "pages": 32,
                    "bLink": "ujei"
                  }
                ]
              }
            },
            {
              "version": "湘教版",
              "count": 3,
              "grades": {
                "八年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 湘教版初中地理 教学设计与指导 八年级上册",
                    "url": "https://book.yunzhan365.com/luloc/ttac/",
                    "pages": 32,
                    "bLink": "ttac"
                  }
                ],
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 湘教版初中地理 教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/mnow/",
                    "pages": 32,
                    "bLink": "mnow"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 湘教版初中地理 教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/ngvh/",
                    "pages": 52,
                    "bLink": "ngvh"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "生物",
          "count": 4,
          "versions": [
            {
              "version": "人教版",
              "count": 4,
              "grades": {
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版初中生物学教科书教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/zvvc/",
                    "pages": 32,
                    "bLink": "zvvc"
                  },
                  {
                    "term": "下册",
                    "title": "人教版初中生物学教科书教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/tlya/",
                    "pages": 26,
                    "bLink": "tlya"
                  }
                ],
                "八年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版初中生物学教科书教学设计与指导 八年级上册",
                    "url": "https://book.yunzhan365.com/luloc/kxck/",
                    "pages": 32,
                    "bLink": "kxck"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 人教版初中生物教科书教学设计与指导 八年级下册",
                    "url": "https://book.yunzhan365.com/luloc/eljn/",
                    "pages": 49,
                    "bLink": "eljn"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "化学",
          "count": 2,
          "versions": [
            {
              "version": "人教版",
              "count": 2,
              "grades": {
                "九年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版初中化学教科书教学设计与指导 九年级上册",
                    "url": "https://book.yunzhan365.com/luloc/ohhz/",
                    "pages": 32,
                    "bLink": "ohhz"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 人教版初中化学教科书教学设计与指导 九年级下册",
                    "url": "https://book.yunzhan365.com/luloc/ptff/",
                    "pages": 32,
                    "bLink": "ptff"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "物理",
          "count": 5,
          "versions": [
            {
              "version": "人教版",
              "count": 5,
              "grades": {
                "八年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 人教版初中物理教科书教学设计与指导 八年级上册",
                    "url": "https://book.yunzhan365.com/luloc/dxhs/",
                    "pages": 32,
                    "bLink": "dxhs"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 人教版初中物理教科书教学设计与指导 八年级下册",
                    "url": "https://book.yunzhan365.com/luloc/nngt/",
                    "pages": 24,
                    "bLink": "nngt"
                  }
                ],
                "九年级": [
                  {
                    "term": "",
                    "title": "2026年春版 人教版初中物理教科书教学设计与指导 九年级全一册（上）",
                    "url": "https://book.yunzhan365.com/luloc/ncfp/",
                    "pages": 46,
                    "bLink": "ncfp"
                  },
                  {
                    "term": "",
                    "title": "2026年春版 人教版初中物理教科书教学设计与指导 九年级全一册（下）",
                    "url": "https://book.yunzhan365.com/luloc/absy/",
                    "pages": 56,
                    "bLink": "absy"
                  },
                  {
                    "term": "",
                    "title": "2026年春版 人教版初中物理教科书教学设计与指导 九年级全一册（总复习指导）",
                    "url": "https://book.yunzhan365.com/luloc/flqn/",
                    "pages": 42,
                    "bLink": "flqn"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "科学",
          "count": 2,
          "versions": [
            {
              "version": "浙教版",
              "count": 2,
              "grades": {
                "七年级": [
                  {
                    "term": "上册",
                    "title": "2025年秋版 浙教版初中科学 教学设计与指导 七年级上册",
                    "url": "https://book.yunzhan365.com/luloc/hscy/",
                    "pages": 33,
                    "bLink": "hscy"
                  },
                  {
                    "term": "下册",
                    "title": "2026年春版 浙教版初中科学 教学设计与指导 七年级下册",
                    "url": "https://book.yunzhan365.com/luloc/hwev/",
                    "pages": 50,
                    "bLink": "hwev"
                  }
                ]
              }
            }
          ]
        }
      ]
    },
    {
      "stage": "高中",
      "subjects": [
        {
          "name": "语文",
          "count": 5,
          "versions": [
            {
              "version": "统编版",
              "count": 5,
              "grades": {
                "必修上": [
                  {
                    "term": "",
                    "title": "统编版高中语文 教学设计与指导 必修上册",
                    "url": "https://book.yunzhan365.com/luloc/vpwt/",
                    "pages": 32,
                    "bLink": "vpwt"
                  }
                ],
                "必修下": [
                  {
                    "term": "",
                    "title": " 统编版高中语文 教学设计与指导 必修下册",
                    "url": "https://book.yunzhan365.com/luloc/warl/",
                    "pages": 32,
                    "bLink": "warl"
                  }
                ],
                "选择性必修上": [
                  {
                    "term": "",
                    "title": " 统编版高中语文 教学设计与指导 选择性必修上册",
                    "url": "https://book.yunzhan365.com/luloc/kbzd/",
                    "pages": 32,
                    "bLink": "kbzd"
                  }
                ],
                "选择性必修中": [
                  {
                    "term": "",
                    "title": "统编版高中语文 教学设计与指导 选择性必修 中册",
                    "url": "https://book.yunzhan365.com/luloc/cpzb/",
                    "pages": 32,
                    "bLink": "cpzb"
                  }
                ],
                "选择性必修下": [
                  {
                    "term": "",
                    "title": "统编版高中语文 教学设计与指导 选择性必修下册",
                    "url": "https://book.yunzhan365.com/luloc/gsvf/",
                    "pages": 32,
                    "bLink": "gsvf"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "数学",
          "count": 5,
          "versions": [
            {
              "version": "人教A版",
              "count": 5,
              "grades": {
                "必修上": [
                  {
                    "term": "",
                    "title": "人教A版高中数学 教学设计与指导 必修第一册",
                    "url": "https://book.yunzhan365.com/luloc/ibyy/",
                    "pages": 32,
                    "bLink": "ibyy"
                  }
                ],
                "必修下": [
                  {
                    "term": "",
                    "title": "人教A版高中数学 教学设计与指导 必修第二册",
                    "url": "https://book.yunzhan365.com/luloc/djch/",
                    "pages": 32,
                    "bLink": "djch"
                  }
                ],
                "选择性必修上": [
                  {
                    "term": "",
                    "title": "人教A版高中数学 教学设计与指导 选择性必修第一册",
                    "url": "https://book.yunzhan365.com/luloc/gxte/",
                    "pages": 32,
                    "bLink": "gxte"
                  }
                ],
                "选择性必修中": [
                  {
                    "term": "",
                    "title": " 人教A版高中数学 教学设计与指导 选择性必修第二册",
                    "url": "https://book.yunzhan365.com/luloc/pbsa/",
                    "pages": 32,
                    "bLink": "pbsa"
                  }
                ],
                "选择性必修下": [
                  {
                    "term": "",
                    "title": "人教A版高中数学 教学设计与指导 选择性必修第三册",
                    "url": "https://book.yunzhan365.com/luloc/pvdy/",
                    "pages": 32,
                    "bLink": "pvdy"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "英语",
          "count": 14,
          "versions": [
            {
              "version": "人教版",
              "count": 7,
              "grades": {
                "必修上": [
                  {
                    "term": "",
                    "title": "人教版高中英语 教学设计与指导 必修第一册",
                    "url": "https://book.yunzhan365.com/luloc/qiib/",
                    "pages": 32,
                    "bLink": "qiib"
                  }
                ],
                "必修下": [
                  {
                    "term": "",
                    "title": "人教版高中英语 教学设计与指导 必修第二册",
                    "url": "https://book.yunzhan365.com/luloc/plud/",
                    "pages": 32,
                    "bLink": "plud"
                  },
                  {
                    "term": "",
                    "title": "人教版高中英语 教学设计与指导 必修第三册",
                    "url": "https://book.yunzhan365.com/luloc/zqqh/",
                    "pages": 32,
                    "bLink": "zqqh"
                  }
                ],
                "选择性必修上": [
                  {
                    "term": "",
                    "title": "人教版高中英语 教学设计与指导 选择性必修第一册",
                    "url": "https://book.yunzhan365.com/luloc/ueal/",
                    "pages": 32,
                    "bLink": "ueal"
                  }
                ],
                "选择性必修中": [
                  {
                    "term": "",
                    "title": "人教版高中英语 教学设计与指导 选择性必修第二册",
                    "url": "https://book.yunzhan365.com/luloc/hyws/",
                    "pages": 32,
                    "bLink": "hyws"
                  }
                ],
                "选择性必修下": [
                  {
                    "term": "",
                    "title": " 人教版高中英语 教学设计与指导 选择性必修第三册",
                    "url": "https://book.yunzhan365.com/luloc/pgjj/",
                    "pages": 32,
                    "bLink": "pgjj"
                  },
                  {
                    "term": "",
                    "title": "人教版高中英语 教学设计与指导 选择性必修第四册",
                    "url": "https://book.yunzhan365.com/luloc/crhb/",
                    "pages": 32,
                    "bLink": "crhb"
                  }
                ]
              }
            },
            {
              "version": "外研版",
              "count": 7,
              "grades": {
                "必修上": [
                  {
                    "term": "",
                    "title": "外研版高中英语 教学设计与指导 必修第一册",
                    "url": "https://book.yunzhan365.com/luloc/ahxe/",
                    "pages": 32,
                    "bLink": "ahxe"
                  }
                ],
                "必修下": [
                  {
                    "term": "",
                    "title": " 外研版高中英语 教学设计与指导 必修第二册",
                    "url": "https://book.yunzhan365.com/luloc/dxhe/",
                    "pages": 32,
                    "bLink": "dxhe"
                  },
                  {
                    "term": "",
                    "title": "外研版高中英语 教学设计与指导 必修第三册",
                    "url": "https://book.yunzhan365.com/luloc/apoq/",
                    "pages": 32,
                    "bLink": "apoq"
                  }
                ],
                "选择性必修上": [
                  {
                    "term": "",
                    "title": "外研版高中英语 教学设计与指导 选择性必修1",
                    "url": "https://book.yunzhan365.com/luloc/fgpq/",
                    "pages": 32,
                    "bLink": "fgpq"
                  }
                ],
                "选择性必修中": [
                  {
                    "term": "",
                    "title": "外研版高中英语 教学设计与指导 选择性必修2",
                    "url": "https://book.yunzhan365.com/luloc/jlni/",
                    "pages": 32,
                    "bLink": "jlni"
                  }
                ],
                "选择性必修下": [
                  {
                    "term": "",
                    "title": "外研版高中英语 教学设计与指导 选择性必修3",
                    "url": "https://book.yunzhan365.com/luloc/sjwy/",
                    "pages": 32,
                    "bLink": "sjwy"
                  },
                  {
                    "term": "",
                    "title": "外研版高中英语 教学设计与指导 选择性必修4",
                    "url": "https://book.yunzhan365.com/luloc/clfn/",
                    "pages": 32,
                    "bLink": "clfn"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "思想政治",
          "count": 7,
          "versions": [
            {
              "version": "统编版",
              "count": 7,
              "grades": {
                "必修上": [
                  {
                    "term": "",
                    "title": "统编版高中思想政治 教学设计与指导 必修第一册",
                    "url": "https://book.yunzhan365.com/luloc/grsq/",
                    "pages": 32,
                    "bLink": "grsq"
                  }
                ],
                "必修下": [
                  {
                    "term": "",
                    "title": "统编版高中思想政治 教学设计与指导 必修第二册",
                    "url": "https://book.yunzhan365.com/luloc/rmgy/",
                    "pages": 32,
                    "bLink": "rmgy"
                  },
                  {
                    "term": "",
                    "title": "统编版高中思想政治 教学设计与指导 必修第三册",
                    "url": "https://book.yunzhan365.com/luloc/ahdz/",
                    "pages": 32,
                    "bLink": "ahdz"
                  },
                  {
                    "term": "",
                    "title": "统编版高中思想政治 教学设计与指导 必修第四册",
                    "url": "https://book.yunzhan365.com/luloc/ucgx/",
                    "pages": 32,
                    "bLink": "ucgx"
                  }
                ],
                "选择性必修下": [
                  {
                    "term": "",
                    "title": " 统编版高中思想政治 教学设计与指导 选择性必修第三册",
                    "url": "https://book.yunzhan365.com/luloc/atfj/",
                    "pages": 32,
                    "bLink": "atfj"
                  }
                ],
                "选择性必修上": [
                  {
                    "term": "",
                    "title": " 统编版高中思想政治 教学设计与指导 选择性必修第一册",
                    "url": "https://book.yunzhan365.com/luloc/qhqo/",
                    "pages": 32,
                    "bLink": "qhqo"
                  }
                ],
                "选择性必修中": [
                  {
                    "term": "",
                    "title": " 统编版高中思想政治 教学设计与指导 选择性必修第二册",
                    "url": "https://book.yunzhan365.com/luloc/mdgz/",
                    "pages": 32,
                    "bLink": "mdgz"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "历史",
          "count": 5,
          "versions": [
            {
              "version": "统编版",
              "count": 5,
              "grades": {
                "必修上": [
                  {
                    "term": "",
                    "title": "统编高中历史 教学设计与指导 必修 中外历史纲要上",
                    "url": "https://book.yunzhan365.com/luloc/xzaf/",
                    "pages": 32,
                    "bLink": "xzaf"
                  }
                ],
                "必修下": [
                  {
                    "term": "",
                    "title": "统编高中历史 教学设计与指导 必修 中外历史纲要下",
                    "url": "https://book.yunzhan365.com/luloc/yvlg/",
                    "pages": 32,
                    "bLink": "yvlg"
                  }
                ],
                "选择性必修上": [
                  {
                    "term": "",
                    "title": " 统编版高中历史 教学设计与指导 选择性必修第一册",
                    "url": "https://book.yunzhan365.com/luloc/svbp/",
                    "pages": 32,
                    "bLink": "svbp"
                  }
                ],
                "选择性必修中": [
                  {
                    "term": "",
                    "title": " 统编版高中历史 教学设计与指导 选择性必修第二册",
                    "url": "https://book.yunzhan365.com/luloc/kbtm/",
                    "pages": 32,
                    "bLink": "kbtm"
                  }
                ],
                "选择性必修下": [
                  {
                    "term": "",
                    "title": " 统编版高中历史 教学设计与指导 选择性必修第三册",
                    "url": "https://book.yunzhan365.com/luloc/etri/",
                    "pages": 32,
                    "bLink": "etri"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "地理",
          "count": 3,
          "versions": [
            {
              "version": "人教版",
              "count": 1,
              "grades": {
                "必修上": [
                  {
                    "term": "",
                    "title": "人教版高中地理 教学设计与指导 必修一",
                    "url": "https://book.yunzhan365.com/luloc/rygc/",
                    "pages": 32,
                    "bLink": "rygc"
                  }
                ]
              }
            },
            {
              "version": "湘教版",
              "count": 2,
              "grades": {
                "必修上": [
                  {
                    "term": "",
                    "title": "湘教版高中地理 教学设计与指导 必修一",
                    "url": "https://book.yunzhan365.com/luloc/bfen/",
                    "pages": 32,
                    "bLink": "bfen"
                  }
                ],
                "必修下": [
                  {
                    "term": "",
                    "title": "湘教版高中地理 教学设计与指导 必修二",
                    "url": "https://book.yunzhan365.com/luloc/qhxe/",
                    "pages": 32,
                    "bLink": "qhxe"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "生物",
          "count": 5,
          "versions": [
            {
              "version": "人教版",
              "count": 5,
              "grades": {
                "必修上": [
                  {
                    "term": "",
                    "title": "人教版高中生物 教学设计与指导 必修第一册",
                    "url": "https://book.yunzhan365.com/luloc/gwzl/",
                    "pages": 32,
                    "bLink": "gwzl"
                  }
                ],
                "必修下": [
                  {
                    "term": "",
                    "title": "人教版高中生物 教学设计与指导 必修第二册",
                    "url": "https://book.yunzhan365.com/luloc/jmzz/",
                    "pages": 32,
                    "bLink": "jmzz"
                  }
                ],
                "选择性必修上": [
                  {
                    "term": "",
                    "title": "人教版高中生物 教学设计与指导 选择性必修第一册",
                    "url": "https://book.yunzhan365.com/luloc/fowt/",
                    "pages": 32,
                    "bLink": "fowt"
                  }
                ],
                "选择性必修中": [
                  {
                    "term": "",
                    "title": " 人教版高中生物 教学设计与指导 选择性必修第二册",
                    "url": "https://book.yunzhan365.com/luloc/eqch/",
                    "pages": 32,
                    "bLink": "eqch"
                  }
                ],
                "选择性必修下": [
                  {
                    "term": "",
                    "title": " 人教版高中生物 教学设计与指导 选择性必修第三册",
                    "url": "https://book.yunzhan365.com/luloc/kudh/",
                    "pages": 32,
                    "bLink": "kudh"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "化学",
          "count": 5,
          "versions": [
            {
              "version": "人教版",
              "count": 5,
              "grades": {
                "必修上": [
                  {
                    "term": "",
                    "title": "人教版高中化学 教学设计与指导 必修第一册",
                    "url": "https://book.yunzhan365.com/luloc/daox/",
                    "pages": 32,
                    "bLink": "daox"
                  }
                ],
                "必修下": [
                  {
                    "term": "",
                    "title": " 人教版高中化学 教学设计与指导 必修第二册",
                    "url": "https://book.yunzhan365.com/luloc/zwey/",
                    "pages": 32,
                    "bLink": "zwey"
                  }
                ],
                "选择性必修上": [
                  {
                    "term": "",
                    "title": "人教版高中化学 教学设计与指导 选择性必修第一册",
                    "url": "https://book.yunzhan365.com/luloc/kbqr/",
                    "pages": 32,
                    "bLink": "kbqr"
                  }
                ],
                "选择性必修中": [
                  {
                    "term": "",
                    "title": "人教版高中化学 教学设计与指导 选择性必修第二册",
                    "url": "https://book.yunzhan365.com/luloc/ztwk/",
                    "pages": 32,
                    "bLink": "ztwk"
                  }
                ],
                "选择性必修下": [
                  {
                    "term": "",
                    "title": " 人教版高中化学 教学设计与指导 选择性必修第三册",
                    "url": "https://book.yunzhan365.com/luloc/ogms/",
                    "pages": 32,
                    "bLink": "ogms"
                  }
                ]
              }
            }
          ]
        },
        {
          "name": "物理",
          "count": 6,
          "versions": [
            {
              "version": "人教版",
              "count": 6,
              "grades": {
                "必修上": [
                  {
                    "term": "",
                    "title": " 人教版高中物理 教学设计与指导 必修第一册",
                    "url": "https://book.yunzhan365.com/luloc/uobm/",
                    "pages": 32,
                    "bLink": "uobm"
                  }
                ],
                "必修下": [
                  {
                    "term": "",
                    "title": "人教版高中物理 教学设计与指导 必修第二册",
                    "url": "https://book.yunzhan365.com/luloc/tqcj/",
                    "pages": 32,
                    "bLink": "tqcj"
                  },
                  {
                    "term": "",
                    "title": "人教版高中物理 教学设计与指导 必修第三册",
                    "url": "https://book.yunzhan365.com/luloc/wolf/",
                    "pages": 32,
                    "bLink": "wolf"
                  }
                ],
                "选择性必修上": [
                  {
                    "term": "",
                    "title": " 人教版高中物理 教学设计与指导 选择性必修第一册",
                    "url": "https://book.yunzhan365.com/luloc/wnwr/",
                    "pages": 32,
                    "bLink": "wnwr"
                  }
                ],
                "选择性必修中": [
                  {
                    "term": "",
                    "title": "人教版高中物理 教学设计与指导 选择性必修第二册",
                    "url": "https://book.yunzhan365.com/luloc/etxg/",
                    "pages": 32,
                    "bLink": "etxg"
                  }
                ],
                "选择性必修下": [
                  {
                    "term": "",
                    "title": "人教版高中物理 教学设计与指导 选择性必修第三册",
                    "url": "https://book.yunzhan365.com/luloc/sibg/",
                    "pages": 32,
                    "bLink": "sibg"
                  }
                ]
              }
            }
          ]
        }
      ]
    }
  ]
}
  // 以后加新出版社，参考下面的模板：
  // {
  //   id: 'rjjiao-cn', name: '人教社', series: '人教版教参', logo: '📕',
  //   description: '...', trialType: 'link', trialUrl: 'https://...',
  //   totalBooks: 30,
  //   categories: [
  //     { stage: '小学', subjects: [
  //       { name: '语文', count: 6, versions: [
  //         { version: '人教版', count: 6, grades: {
  //           '一年级': [{ term: '上册', title: '...', url: 'https://...', pages: 32 }]
  //         }}
  //       ]}
  //     ]}
  //   ]
  // }
];
